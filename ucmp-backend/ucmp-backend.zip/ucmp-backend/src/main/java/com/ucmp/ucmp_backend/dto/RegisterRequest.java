package com.ucmp.ucmp_backend.dto;

import com.ucmp.ucmp_backend.model.RoleName;
import lombok.*;
import jakarta.validation.constraints.*;

@Getter @Setter
@Data @Builder

@AllArgsConstructor
@NoArgsConstructor
public class RegisterRequest {
    @NotBlank
    private String collegeId;
    @NotBlank
    private String name;
    @NotBlank
    @Email
    private String email;
    @NotBlank
    private String password;
    private RoleName role; // Use the RoleName enum directly
    private String rollNumber;
    private String year;
    private String branch;
    private String department;
    private String designation;
}