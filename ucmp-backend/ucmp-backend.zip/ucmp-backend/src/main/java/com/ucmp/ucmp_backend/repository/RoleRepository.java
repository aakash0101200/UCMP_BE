package com.ucmp.ucmp_backend.repository;

import com.ucmp.ucmp_backend.model.Role;
import com.ucmp.ucmp_backend.model.RoleName;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface RoleRepository extends JpaRepository<Role, Long> {
    Optional<Role> findByName(RoleName name);
}
